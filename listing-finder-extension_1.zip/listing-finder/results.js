const $ = id => document.getElementById(id);
const params = new URLSearchParams(location.search);
const runId = params.get('run') || 'run_unknown';
const inputUrl = params.get('url') || '';
const depth = params.get('depth') || 'standard';
const verifyOnRun = params.get('verify') !== '0';

const target = LF.normalizeInputUrl(inputUrl);
const targetRoot = target ? LF.rootDomain(target.hostname) : '';
const bizName = (params.get('name') || '').trim() || (target ? LF.guessName(target.hostname) : '');

let rows = [];           // all found rows
let removed = new Set(); // keys removed by user
let searchesUsed = 0;
let finished = false;
let checking = false;

const MATCH_RANK = { 'Domain mention': 0, 'Name mention': 1, 'Possible match': 2 };
const TYPE_RANK = Object.fromEntries(LF.SITE_TYPES.map((t, i) => [t, i]));
const BL_RANK = { 'Backlink': 0, 'Mention only': 1, 'Checking...': 2, 'Not checked': 3, 'Login site, not checked': 4, 'Could not open page': 5 };

function setProgress(done, total, text, unit) {
  $('progressCard').hidden = false;
  $('barFill').style.width = total ? Math.round((done / total) * 100) + '%' : '0%';
  $('progressText').textContent = text;
  $('progressCount').textContent = total ? `${done} of ${total} ${unit || 'searches'}` : '';
}

function showError(msg) {
  $('err').textContent = msg;
  $('err').hidden = !msg;
}

/* ---------- Search ---------- */

async function serperSearch(apiKey, q, page) {
  const res = await fetch('https://google.serper.dev/search', {
    method: 'POST',
    headers: { 'X-API-KEY': apiKey, 'Content-Type': 'application/json' },
    body: JSON.stringify({ q, num: 10, page })
  });
  if (!res.ok) {
    let detail = '';
    try { detail = (await res.json()).message || ''; } catch (e) { /* ignore */ }
    const err = new Error(detail || ('HTTP ' + res.status));
    err.status = res.status;
    throw err;
  }
  return res.json();
}

function addResults(data, label) {
  const items = (data && data.organic) || [];
  for (const item of items) {
    if (!item.link || LF.isOwnSite(item.link, targetRoot)) continue;
    const key = LF.normalizeResultUrl(item.link);
    if (rows.some(r => r.key === key)) continue;
    const c = LF.classify(item.link, item.title, item.snippet);
    rows.push({
      key,
      siteName: c.siteName,
      siteType: c.siteType,
      domain: c.domain,
      url: item.link,
      title: item.title || '',
      snippet: item.snippet || '',
      match: LF.matchType(item, targetRoot, bizName),
      foundVia: label,
      blStatus: 'Not checked',
      linkType: '',
      anchor: '',
      linksTo: '',
      linkCount: 0
    });
  }
  return items.length;
}

/* ---------- Backlink check ---------- */

async function fetchPage(url) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 12000);
  try {
    const res = await fetch(url, { credentials: 'omit', redirect: 'follow', signal: ctrl.signal, cache: 'no-store' });
    if (!res.ok) throw new Error('HTTP ' + res.status);
    const type = res.headers.get('content-type') || '';
    if (type && !/html|xml|text\/plain/i.test(type)) throw new Error('Not a web page');
    const text = await res.text();
    return { html: text.slice(0, 4000000), finalUrl: res.url || url };
  } finally {
    clearTimeout(timer);
  }
}

async function checkRow(r) {
  if (!LF.canFetch(r.url)) {
    r.blStatus = 'Login site, not checked';
    return;
  }
  r.blStatus = 'Checking...';
  try {
    const { html, finalUrl } = await fetchPage(r.url);
    const res = LF.analyzeHtml(html, finalUrl, targetRoot);
    r.blStatus = res.status;
    r.linkType = res.linkType;
    r.anchor = res.anchor;
    r.linksTo = res.linksTo;
    r.linkCount = res.linkCount;
  } catch (e) {
    r.blStatus = 'Could not open page';
  }
}

async function checkBacklinks() {
  const todo = rows.filter(r => !removed.has(r.key) && (r.blStatus === 'Not checked' || r.blStatus === 'Checking...'));
  if (!todo.length) return;
  checking = true;
  $('checkBtn').hidden = true;
  let done = 0;
  setProgress(0, todo.length, 'Checking backlinks...', 'pages');
  let idx = 0;
  const worker = async () => {
    while (idx < todo.length) {
      const r = todo[idx++];
      await checkRow(r);
      done++;
      setProgress(done, todo.length, `Checking backlinks: ${r.domain}`, 'pages');
      if (done % 3 === 0 || done === todo.length) render();
    }
  };
  await Promise.all([worker(), worker(), worker(), worker()]);
  checking = false;
}

/* ---------- View ---------- */

function blLabel(r) {
  return r.blStatus === 'Backlink' ? r.linkType : r.blStatus;
}

function blClass(r) {
  if (r.blStatus !== 'Backlink') {
    if (r.blStatus === 'Mention only') return 'b-mention';
    if (r.blStatus === 'Checking...') return 'b-checking';
    return 'b-unknown';
  }
  if (r.linkType.startsWith('Dofollow')) return 'b-dofollow';
  if (r.linkType.startsWith('Nofollow')) return 'b-nofollow';
  return 'b-other';
}

function sortRows() {
  rows.sort((a, b) =>
    ((BL_RANK[a.blStatus] ?? 9) - (BL_RANK[b.blStatus] ?? 9)) ||
    ((a.blStatus === 'Backlink' && b.blStatus === 'Backlink') ? (a.linkType.startsWith('Dofollow') ? 0 : 1) - (b.linkType.startsWith('Dofollow') ? 0 : 1) : 0) ||
    (MATCH_RANK[a.match] - MATCH_RANK[b.match]) ||
    ((TYPE_RANK[a.siteType] ?? 99) - (TYPE_RANK[b.siteType] ?? 99)) ||
    a.siteName.localeCompare(b.siteName)
  );
}

function visibleRows() {
  return rows.filter(r => !removed.has(r.key));
}

function filteredRows() {
  const text = $('filterText').value.trim().toLowerCase();
  const type = $('filterType').value;
  const match = $('filterMatch').value;
  const bl = $('filterBl').value;
  return visibleRows().filter(r =>
    (!type || r.siteType === type) &&
    (!match || r.match === match) &&
    (!bl ||
      (bl === 'backlink' && r.blStatus === 'Backlink') ||
      (bl === 'dofollow' && r.blStatus === 'Backlink' && r.linkType.startsWith('Dofollow')) ||
      (bl === 'nofollow' && r.blStatus === 'Backlink' && !r.linkType.startsWith('Dofollow')) ||
      (bl === 'mention' && r.blStatus === 'Mention only') ||
      (bl === 'unknown' && !['Backlink', 'Mention only'].includes(r.blStatus))) &&
    (!text || (r.siteName + ' ' + r.url + ' ' + r.title + ' ' + r.anchor).toLowerCase().includes(text))
  );
}

function esc(s) {
  return String(s).replace(/[&<>"']/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]));
}

function slug(t) {
  return t.toLowerCase().replace(/[^a-z]+/g, '-');
}

function render() {
  sortRows();
  const vis = visibleRows();
  const backlinks = vis.filter(r => r.blStatus === 'Backlink');
  const dofollow = backlinks.filter(r => r.linkType.startsWith('Dofollow'));

  const counts = {};
  vis.forEach(r => { counts[r.siteType] = (counts[r.siteType] || 0) + 1; });
  const statTypes = Object.keys(counts).sort((a, b) => counts[b] - counts[a]);
  $('stats').innerHTML =
    `<div class="stat main"><b>${backlinks.length}</b><span>Backlinks found</span></div>` +
    `<div class="stat"><b>${dofollow.length}</b><span>Dofollow</span></div>` +
    `<div class="stat"><b>${backlinks.length - dofollow.length}</b><span>Nofollow / other</span></div>` +
    `<div class="stat"><b>${new Set(backlinks.map(r => r.domain)).size}</b><span>Linking websites</span></div>` +
    `<div class="stat"><b>${vis.length}</b><span>Total listings &amp; mentions</span></div>` +
    statTypes.slice(0, 2).map(t => `<div class="stat"><b>${counts[t]}</b><span>${esc(t)}</span></div>`).join('');

  const sel = $('filterType');
  const cur = sel.value;
  sel.innerHTML = '<option value="">All site types</option>' +
    statTypes.map(t => `<option value="${esc(t)}">${esc(t)} (${counts[t]})</option>`).join('');
  sel.value = statTypes.includes(cur) ? cur : '';

  const list = filteredRows();
  $('rows').innerHTML = list.map((r, i) => `
    <tr>
      <td class="num muted">${i + 1}</td>
      <td><div class="site">${esc(r.siteName)}</div><div class="muted small">${esc(r.domain)}</div></td>
      <td><span class="tag t-${slug(r.siteType)}">${esc(r.siteType)}</span></td>
      <td class="url"><a href="${esc(r.url)}" target="_blank" rel="noopener">${esc(r.url)}</a>
        <div class="muted small title-line" title="${esc(r.snippet)}">${esc(r.title)}</div></td>
      <td><span class="bl ${blClass(r)}">${esc(blLabel(r))}</span>${r.linkCount > 1 ? `<div class="muted small">${r.linkCount} links</div>` : ''}</td>
      <td class="anchor">${r.anchor ? esc(r.anchor) : '<span class="muted">-</span>'}
        ${r.linksTo ? `<div class="muted small to">to ${esc(r.linksTo)}</div>` : ''}</td>
      <td><span class="match m-${slug(r.match)}">${esc(r.match)}</span></td>
      <td class="num"><button class="x" data-key="${esc(r.key)}" title="Remove this row">&times;</button></td>
    </tr>`).join('');
  $('empty').hidden = list.length > 0;
  $('shown').textContent = `${list.length} shown`;

  const hasData = vis.length > 0;
  $('dlXlsx').disabled = !hasData || checking;
  $('dlCsv').disabled = !hasData || checking;
  $('checkBtn').hidden = !(finished && !checking && vis.some(r => r.blStatus === 'Not checked'));
}

async function saveRun() {
  try {
    await chrome.storage.local.set({ [runId]: { rows, removed: [...removed], searchesUsed, finished, savedAt: Date.now() } });
  } catch (e) { /* ignore */ }
}

/* ---------- Export ---------- */

function fullRow(r, i) {
  return {
    '#': i + 1,
    'Site Name': r.siteName,
    'Site Type': r.siteType,
    'Page URL': r.url,
    'Backlink Status': r.blStatus === 'Backlink' ? 'Backlink' : r.blStatus,
    'Link Type': r.linkType,
    'Anchor Text': r.anchor,
    'Links To': r.linksTo,
    'Website Domain': r.domain,
    'Page Title': r.title,
    'Snippet': r.snippet,
    'Match': r.match,
    'Found Via': r.foundVia
  };
}

function backlinkRow(r, i) {
  return {
    '#': i + 1,
    'Site Name': r.siteName,
    'Site Type': r.siteType,
    'Backlink Page URL': r.url,
    'Link Type': r.linkType,
    'Anchor Text': r.anchor,
    'Links To': r.linksTo,
    'Website Domain': r.domain,
    'Page Title': r.title
  };
}

function fileBase() {
  const d = new Date().toISOString().slice(0, 10);
  return `backlinks-${targetRoot.replace(/[^a-z0-9.-]/gi, '')}-${d}`;
}

function makeSheet(data, headers, widths, linkCols) {
  const ws = data.length ? XLSX.utils.json_to_sheet(data, { header: headers }) : XLSX.utils.aoa_to_sheet([headers]);
  ws['!cols'] = widths.map(w => ({ wch: w }));
  ws['!autofilter'] = { ref: XLSX.utils.encode_range({ s: { r: 0, c: 0 }, e: { r: Math.max(data.length, 1), c: headers.length - 1 } }) };
  data.forEach((row, i) => {
    linkCols.forEach(col => {
      const c = headers.indexOf(col);
      const ref = XLSX.utils.encode_cell({ r: i + 1, c });
      if (ws[ref] && /^https?:\/\//i.test(row[col])) ws[ref].l = { Target: row[col] };
    });
  });
  return ws;
}

function downloadXlsx() {
  const list = filteredRows();
  const bl = list.filter(r => r.blStatus === 'Backlink');
  const blData = bl.map(backlinkRow);
  const allData = list.map(fullRow);

  const blHeaders = ['#', 'Site Name', 'Site Type', 'Backlink Page URL', 'Link Type', 'Anchor Text', 'Links To', 'Website Domain', 'Page Title'];
  const allHeaders = Object.keys(fullRow(rows[0] || { siteName: '', siteType: '', url: '', blStatus: '', linkType: '', anchor: '', linksTo: '', domain: '', title: '', snippet: '', match: '', foundVia: '' }, 0));

  const ws1 = makeSheet(blData, blHeaders, [5, 24, 22, 60, 18, 30, 45, 26, 50], ['Backlink Page URL', 'Links To']);
  const ws2 = makeSheet(allData, allHeaders, [5, 24, 22, 60, 22, 18, 30, 45, 26, 50, 70, 16, 24], ['Page URL', 'Links To']);

  const typeCounts = {};
  bl.forEach(r => { typeCounts[r.siteType] = (typeCounts[r.siteType] || 0) + 1; });
  const dof = bl.filter(r => r.linkType.startsWith('Dofollow')).length;
  const summary = [
    ['Backlink report'],
    [],
    ['Website', target ? target.origin : inputUrl],
    ['Business name', bizName],
    ['Report date', new Date().toLocaleString()],
    ['Search depth', depth],
    [],
    ['Backlinks found', bl.length],
    ['Dofollow', dof],
    ['Nofollow / UGC / Sponsored', bl.length - dof],
    ['Linking websites', new Set(bl.map(r => r.domain)).size],
    ['Mentions without link', list.filter(r => r.blStatus === 'Mention only').length],
    ['Pages not checked', list.filter(r => !['Backlink', 'Mention only'].includes(r.blStatus)).length],
    ['Total listings and mentions', list.length],
    [],
    ['Backlinks by site type', 'Count'],
    ...Object.keys(typeCounts).sort((a, b) => typeCounts[b] - typeCounts[a]).map(t => [t, typeCounts[t]])
  ];
  const ws3 = XLSX.utils.aoa_to_sheet(summary);
  ws3['!cols'] = [{ wch: 30 }, { wch: 50 }];

  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws1, 'Backlinks');
  XLSX.utils.book_append_sheet(wb, ws2, 'All Results');
  XLSX.utils.book_append_sheet(wb, ws3, 'Summary');
  XLSX.writeFile(wb, fileBase() + '.xlsx');
}

function downloadCsv() {
  const data = filteredRows().map(fullRow);
  const headers = Object.keys(data[0] || { '#': '' });
  const cell = v => '"' + String(v ?? '').replace(/"/g, '""') + '"';
  const csv = [headers.map(cell).join(','), ...data.map(r => headers.map(h => cell(r[h])).join(','))].join('\r\n');
  const blob = new Blob(['﻿' + csv], { type: 'text/csv;charset=utf-8' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = fileBase() + '.csv';
  document.body.appendChild(a);
  a.click();
  setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 1000);
}

/* ---------- Main flow ---------- */

function summaryText() {
  const vis = visibleRows();
  const bl = vis.filter(r => r.blStatus === 'Backlink').length;
  const anyChecked = vis.some(r => r.blStatus !== 'Not checked');
  return anyChecked
    ? `Done. ${bl} backlinks confirmed out of ${vis.length} listings and mentions (${searchesUsed} searches used).`
    : `Done. ${vis.length} listings and mentions found (${searchesUsed} searches used). Click "Check backlinks" to verify links.`;
}

async function run() {
  if (!target) {
    $('heading').textContent = 'Invalid URL';
    showError('The URL could not be read. Open the extension and try again with a URL like example.com');
    $('progressCard').hidden = true;
    return;
  }
  $('heading').textContent = `Backlinks for ${bizName || targetRoot}`;
  $('sub').textContent = `${targetRoot}  ·  ${depth} search`;
  document.title = `Backlinks: ${targetRoot}`;

  const saved = (await chrome.storage.local.get(runId))[runId];
  if (saved && saved.finished) {
    rows = saved.rows || [];
    removed = new Set(saved.removed || []);
    searchesUsed = saved.searchesUsed || 0;
    rows.forEach(r => { if (r.blStatus === 'Checking...') r.blStatus = 'Not checked'; });
    finished = true;
    $('progressCard').hidden = true;
    render();
    return;
  }

  const { apiKey } = await chrome.storage.local.get('apiKey');
  if (!apiKey) {
    showError('No API key saved. Click the extension icon and add your Serper API key first.');
    $('progressCard').hidden = true;
    return;
  }

  const queries = LF.buildQueries(targetRoot, bizName, depth);
  const shortPages = {};
  for (let i = 0; i < queries.length; i++) {
    const { q, page, label } = queries[i];
    const baseLabel = label.replace(/ p\d+$/, '');
    if (page > 1 && shortPages[baseLabel]) {
      setProgress(i + 1, queries.length, `Skipping ${label} (no more results)`);
      continue;
    }
    setProgress(i, queries.length, `Searching: ${label}`);
    try {
      const data = await serperSearch(apiKey, q, page);
      searchesUsed++;
      if (addResults(data, label) < 8) shortPages[baseLabel] = true;
      render();
    } catch (e) {
      if (e.status === 401 || e.status === 403) {
        showError('Your Serper API key was rejected. Click the extension icon, choose "Change API key" and paste a valid key.');
        break;
      }
      if (e.status === 400 && /credit/i.test(e.message)) {
        showError('Your Serper account is out of credits. Results found so far are shown below.');
        break;
      }
      if (e.status === 429 && !queries[i].retried) {
        queries[i].retried = true;
        await new Promise(r => setTimeout(r, 2500));
        i--;
        continue;
      }
      console.warn('Search failed:', label, e);
    }
  }

  if (verifyOnRun) await checkBacklinks();

  finished = true;
  setProgress(1, 1, summaryText(), '');
  $('progressCount').textContent = '';
  render();
  saveRun();
}

$('rows').addEventListener('click', e => {
  const btn = e.target.closest('button.x');
  if (!btn) return;
  removed.add(btn.dataset.key);
  render();
  if (finished) saveRun();
});
['filterText', 'filterType', 'filterMatch', 'filterBl'].forEach(id => $(id).addEventListener('input', render));
$('dlXlsx').addEventListener('click', downloadXlsx);
$('dlCsv').addEventListener('click', downloadCsv);
$('checkBtn').addEventListener('click', async () => {
  render();
  await checkBacklinks();
  setProgress(1, 1, summaryText(), '');
  $('progressCount').textContent = '';
  render();
  saveRun();
});

run();
