const $ = id => document.getElementById(id);
let nameEdited = false;

function showError(msg) {
  const el = $('err');
  el.textContent = msg;
  el.hidden = !msg;
}

function fillFromUrl(raw) {
  const u = LF.normalizeInputUrl(raw);
  if (!u) return;
  if (!nameEdited) $('name').value = LF.guessName(u.hostname);
}

async function currentTabUrl() {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab && tab.url && /^https?:/i.test(tab.url)) return tab.url;
  } catch (e) { /* ignore */ }
  return '';
}

async function init() {
  const { apiKey } = await chrome.storage.local.get('apiKey');
  if (!apiKey) {
    $('setup').hidden = false;
    return;
  }
  $('main').hidden = false;
  $('changeKey').hidden = false;

  const { lastInput } = await chrome.storage.local.get('lastInput');
  if (lastInput) {
    $('url').value = lastInput.url || '';
    $('name').value = lastInput.name || '';
    $('depth').value = lastInput.depth || 'standard';
    $('verify').checked = lastInput.verify !== false;
    nameEdited = !!lastInput.name;
  }
  if (!$('url').value) {
    const tabUrl = await currentTabUrl();
    if (tabUrl) {
      const u = LF.normalizeInputUrl(tabUrl);
      $('url').value = u.origin;
      fillFromUrl(u.origin);
    }
  }
  $('url').focus();
}

$('saveKey').addEventListener('click', async () => {
  const key = $('apiKey').value.trim();
  if (key.length < 10) {
    $('apiKey').focus();
    return;
  }
  await chrome.storage.local.set({ apiKey: key });
  $('setup').hidden = true;
  init();
});

$('changeKey').addEventListener('click', async () => {
  await chrome.storage.local.remove('apiKey');
  $('main').hidden = true;
  $('changeKey').hidden = true;
  $('setup').hidden = false;
});

$('url').addEventListener('input', () => {
  nameEdited = nameEdited && $('name').value.trim() !== '';
  fillFromUrl($('url').value);
});
$('name').addEventListener('input', () => { nameEdited = $('name').value.trim() !== ''; });

$('useTab').addEventListener('click', async () => {
  const tabUrl = await currentTabUrl();
  if (!tabUrl) { showError('This tab has no website URL.'); return; }
  const u = LF.normalizeInputUrl(tabUrl);
  $('url').value = u.origin;
  nameEdited = false;
  fillFromUrl(u.origin);
  showError('');
});

$('go').addEventListener('click', async () => {
  showError('');
  const u = LF.normalizeInputUrl($('url').value);
  if (!u) { showError('Please enter a valid website URL, like example.com'); return; }
  const name = $('name').value.trim();
  const depth = $('depth').value;
  const verify = $('verify').checked;
  await chrome.storage.local.set({ lastInput: { url: $('url').value.trim(), name: nameEdited ? name : '', depth, verify } });

  const runId = 'run_' + Date.now();
  const params = new URLSearchParams({ run: runId, url: u.href, name, depth, verify: verify ? '1' : '0' });
  chrome.tabs.create({ url: chrome.runtime.getURL('results.html?' + params.toString()) });
  window.close();
});

document.addEventListener('keydown', e => {
  if (e.key === 'Enter' && !$('main').hidden) $('go').click();
  if (e.key === 'Enter' && !$('setup').hidden) $('saveKey').click();
});

init();
