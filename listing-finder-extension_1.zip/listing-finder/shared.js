// Shared helpers used by popup.js and results.js
(function (global) {
  const TWO_PART_TLDS = [
    'co.uk', 'org.uk', 'ac.uk', 'gov.uk', 'com.au', 'net.au', 'org.au', 'com.bd', 'net.bd', 'org.bd',
    'co.in', 'com.br', 'com.mx', 'co.nz', 'co.za', 'com.sg', 'com.my', 'co.jp', 'com.tr', 'com.pk',
    'com.ng', 'com.eg', 'co.id', 'com.ph', 'com.ar', 'com.co', 'co.ke', 'com.vn', 'com.hk', 'com.tw'
  ];

  // Known sites: domain -> [Display name, Site type]
  const KNOWN_SITES = {
    // Agency directories
    'clutch.co': ['Clutch', 'Agency Directory'],
    'goodfirms.co': ['GoodFirms', 'Agency Directory'],
    'designrush.com': ['DesignRush', 'Agency Directory'],
    'sortlist.com': ['Sortlist', 'Agency Directory'],
    'themanifest.com': ['The Manifest', 'Agency Directory'],
    'techbehemoths.com': ['TechBehemoths', 'Agency Directory'],
    'agencyspotter.com': ['Agency Spotter', 'Agency Directory'],
    'upcity.com': ['UpCity', 'Agency Directory'],
    'digitalagencynetwork.com': ['Digital Agency Network', 'Agency Directory'],
    'topdevelopers.co': ['TopDevelopers', 'Agency Directory'],
    'appfutura.com': ['AppFutura', 'Agency Directory'],
    'itfirms.co': ['ITFirms', 'Agency Directory'],
    'extract.co': ['Extract', 'Agency Directory'],
    'agencyvista.com': ['Agency Vista', 'Agency Directory'],
    'expertise.com': ['Expertise', 'Agency Directory'],
    'semrush.com': ['Semrush Agency Partners', 'Agency Directory'],
    'awwwards.com': ['Awwwards', 'Design Showcase'],
    'cssdesignawards.com': ['CSS Design Awards', 'Design Showcase'],
    'cssawards.net': ['CSS Awards', 'Design Showcase'],
    'siteinspire.com': ['SiteInspire', 'Design Showcase'],
    'onepagelove.com': ['One Page Love', 'Design Showcase'],
    'land-book.com': ['Land-book', 'Design Showcase'],
    'lapa.ninja': ['Lapa Ninja', 'Design Showcase'],
    'godly.website': ['Godly', 'Design Showcase'],
    'webflow.com': ['Webflow', 'Design Showcase'],
    'framer.com': ['Framer', 'Design Showcase'],
    // Review platforms
    'trustpilot.com': ['Trustpilot', 'Review Platform'],
    'g2.com': ['G2', 'Review Platform'],
    'capterra.com': ['Capterra', 'Review Platform'],
    'sitejabber.com': ['Sitejabber', 'Review Platform'],
    'reviews.io': ['Reviews.io', 'Review Platform'],
    'glassdoor.com': ['Glassdoor', 'Review Platform'],
    'trustradius.com': ['TrustRadius', 'Review Platform'],
    // Business / local directories
    'yelp.com': ['Yelp', 'Business Directory'],
    'bbb.org': ['Better Business Bureau', 'Business Directory'],
    'yellowpages.com': ['Yellow Pages', 'Business Directory'],
    'manta.com': ['Manta', 'Business Directory'],
    'hotfrog.com': ['Hotfrog', 'Business Directory'],
    'cylex.us.com': ['Cylex', 'Business Directory'],
    'brownbook.net': ['Brownbook', 'Business Directory'],
    'foursquare.com': ['Foursquare', 'Business Directory'],
    'tuugo.us': ['Tuugo', 'Business Directory'],
    'bizcommunity.com': ['Bizcommunity', 'Business Directory'],
    'google.com': ['Google', 'Maps & Local'],
    'maps.google.com': ['Google Maps', 'Maps & Local'],
    'bing.com': ['Bing Places', 'Maps & Local'],
    'apple.com': ['Apple', 'Maps & Local'],
    // Company databases
    'crunchbase.com': ['Crunchbase', 'Company Database'],
    'zoominfo.com': ['ZoomInfo', 'Company Database'],
    'rocketreach.co': ['RocketReach', 'Company Database'],
    'apollo.io': ['Apollo', 'Company Database'],
    'pitchbook.com': ['PitchBook', 'Company Database'],
    'dnb.com': ['Dun & Bradstreet', 'Company Database'],
    'owler.com': ['Owler', 'Company Database'],
    'f6s.com': ['F6S', 'Company Database'],
    'wellfound.com': ['Wellfound', 'Company Database'],
    'opencorporates.com': ['OpenCorporates', 'Company Database'],
    'similarweb.com': ['Similarweb', 'Website Analytics'],
    'builtwith.com': ['BuiltWith', 'Website Analytics'],
    'semrush.com/website': ['Semrush', 'Website Analytics'],
    // Social media
    'linkedin.com': ['LinkedIn', 'Social Media'],
    'facebook.com': ['Facebook', 'Social Media'],
    'instagram.com': ['Instagram', 'Social Media'],
    'x.com': ['X (Twitter)', 'Social Media'],
    'twitter.com': ['X (Twitter)', 'Social Media'],
    'threads.net': ['Threads', 'Social Media'],
    'tiktok.com': ['TikTok', 'Social Media'],
    'pinterest.com': ['Pinterest', 'Social Media'],
    'tumblr.com': ['Tumblr', 'Social Media'],
    'bsky.app': ['Bluesky', 'Social Media'],
    // Design portfolio
    'behance.net': ['Behance', 'Design Portfolio'],
    'dribbble.com': ['Dribbble', 'Design Portfolio'],
    'deviantart.com': ['DeviantArt', 'Design Portfolio'],
    'artstation.com': ['ArtStation', 'Design Portfolio'],
    'figma.com': ['Figma Community', 'Design Portfolio'],
    'uplabs.com': ['UpLabs', 'Design Portfolio'],
    // Freelance marketplaces
    'upwork.com': ['Upwork', 'Freelance Marketplace'],
    'fiverr.com': ['Fiverr', 'Freelance Marketplace'],
    'freelancer.com': ['Freelancer', 'Freelance Marketplace'],
    'peopleperhour.com': ['PeoplePerHour', 'Freelance Marketplace'],
    'toptal.com': ['Toptal', 'Freelance Marketplace'],
    'guru.com': ['Guru', 'Freelance Marketplace'],
    'contra.com': ['Contra', 'Freelance Marketplace'],
    '99designs.com': ['99designs', 'Freelance Marketplace'],
    // Video
    'youtube.com': ['YouTube', 'Video'],
    'vimeo.com': ['Vimeo', 'Video'],
    // Developer / product
    'github.com': ['GitHub', 'Developer / Code'],
    'gitlab.com': ['GitLab', 'Developer / Code'],
    'producthunt.com': ['Product Hunt', 'Product Launch'],
    'betalist.com': ['BetaList', 'Product Launch'],
    'indiehackers.com': ['Indie Hackers', 'Forum / Community'],
    // Forums / Q&A
    'reddit.com': ['Reddit', 'Forum / Community'],
    'quora.com': ['Quora', 'Forum / Community'],
    'stackexchange.com': ['Stack Exchange', 'Forum / Community'],
    // Blogs / publishing
    'medium.com': ['Medium', 'Blog / Article'],
    'substack.com': ['Substack', 'Blog / Article'],
    'dev.to': ['DEV Community', 'Blog / Article'],
    'hashnode.com': ['Hashnode', 'Blog / Article'],
    'wordpress.com': ['WordPress.com', 'Blog / Article'],
    'blogspot.com': ['Blogger', 'Blog / Article'],
    // News / press
    'prnewswire.com': ['PR Newswire', 'News / Press'],
    'einpresswire.com': ['EIN Presswire', 'News / Press'],
    'businesswire.com': ['Business Wire', 'News / Press'],
    'globenewswire.com': ['GlobeNewswire', 'News / Press'],
    'forbes.com': ['Forbes', 'News / Press'],
    'entrepreneur.com': ['Entrepreneur', 'News / Press'],
    'techcrunch.com': ['TechCrunch', 'News / Press'],
    // Jobs
    'indeed.com': ['Indeed', 'Job Board'],
    'bdjobs.com': ['Bdjobs', 'Job Board'],
    'wellfound.com/jobs': ['Wellfound Jobs', 'Job Board']
  };

  const SITE_TYPES = [
    'Agency Directory', 'Review Platform', 'Business Directory', 'Maps & Local', 'Company Database',
    'Website Analytics', 'Social Media', 'Design Portfolio', 'Design Showcase', 'Freelance Marketplace',
    'Video', 'Developer / Code', 'Product Launch', 'Forum / Community', 'Blog / Article',
    'News / Press', 'Agency Ranking / List', 'Job Board', 'Website / Other'
  ];

  function normalizeInputUrl(input) {
    let s = (input || '').trim();
    if (!s) return null;
    if (!/^https?:\/\//i.test(s)) s = 'https://' + s;
    try {
      const u = new URL(s);
      if (!u.hostname.includes('.')) return null;
      return u;
    } catch (e) {
      return null;
    }
  }

  function rootDomain(hostname) {
    const host = (hostname || '').toLowerCase().replace(/^www\./, '').replace(/\.$/, '');
    const parts = host.split('.');
    if (parts.length <= 2) return host;
    const lastTwo = parts.slice(-2).join('.');
    if (TWO_PART_TLDS.includes(lastTwo)) return parts.slice(-3).join('.');
    return lastTwo;
  }

  function cleanHost(hostname) {
    return (hostname || '').toLowerCase().replace(/^www\./, '');
  }

  function titleCase(str) {
    return str.replace(/[-_]+/g, ' ').replace(/\s+/g, ' ').trim()
      .split(' ').map(w => w ? w[0].toUpperCase() + w.slice(1) : w).join(' ');
  }

  function guessName(hostname) {
    const root = rootDomain(hostname);
    const label = root.split('.')[0];
    return titleCase(label);
  }

  function lookupKnown(hostname, pathname) {
    const host = cleanHost(hostname);
    const path = (pathname || '').toLowerCase();
    // Special cases that depend on path
    if ((host === 'google.com' || host.endsWith('.google.com')) && (path.startsWith('/maps') || host.startsWith('maps.'))) {
      return ['Google Maps', 'Maps & Local'];
    }
    if (host === 'g.page' || host === 'business.site' || host.endsWith('.business.site')) return ['Google Business Profile', 'Maps & Local'];
    if (host === 'google.com' || host.endsWith('.google.com')) return ['Google', 'Website / Other'];
    if (host === 'semrush.com' && path.startsWith('/agencies')) return ['Semrush Agency Partners', 'Agency Directory'];
    if (host === 'semrush.com' && path.startsWith('/website')) return ['Semrush', 'Website Analytics'];
    if (host === 'semrush.com') return ['Semrush', 'Blog / Article'];
    if (host === 'webflow.com' && !path.startsWith('/made-in-webflow') && !path.startsWith('/@')) return ['Webflow', 'Website / Other'];
    if (host === 'framer.com' && !path.startsWith('/marketplace') && !path.startsWith('/@') && !path.startsWith('/gallery')) return ['Framer', 'Website / Other'];
    if (host === 'apple.com' && !path.startsWith('/maps')) return ['Apple', 'Website / Other'];
    if (host === 'bing.com' && !path.startsWith('/maps')) return ['Bing', 'Website / Other'];
    // Longest matching known domain wins
    let best = null;
    for (const key of Object.keys(KNOWN_SITES)) {
      if (key.includes('/')) continue;
      if (host === key || host.endsWith('.' + key)) {
        if (!best || key.length > best.length) best = key;
      }
    }
    return best ? KNOWN_SITES[best] : null;
  }

  function classify(link, title, snippet) {
    let u;
    try { u = new URL(link); } catch (e) { return { siteName: link, siteType: 'Website / Other', domain: '' }; }
    const host = cleanHost(u.hostname);
    const domain = host;
    const known = lookupKnown(u.hostname, u.pathname);
    if (known) return { siteName: known[0], siteType: known[1], domain };

    const path = u.pathname.toLowerCase();
    const t = (title || '').toLowerCase();
    const sn = (snippet || '').toLowerCase();
    const siteName = guessName(u.hostname);
    let siteType = 'Website / Other';

    if (/\b(top|best|leading)\s+\d*\s*[\w\s-]{0,30}(agencies|companies|firms|studios|designers|developers)\b/.test(t)) {
      siteType = 'Agency Ranking / List';
    } else if (/(review|reviews|rating)/.test(host)) {
      siteType = 'Review Platform';
    } else if (/(blog|medium|substack)/.test(host) || /\/(blog|article|articles|posts?|insights|resources)\//.test(path) || /\bblog\b/.test(t)) {
      siteType = 'Blog / Article';
    } else if (/(directory|listing|listings|companies|firms|agencies|yellow|business(es)?list)/.test(host + path)) {
      siteType = 'Business Directory';
    } else if (/(news|press|pr-?wire|newswire|times|post|journal|magazine|mag\.)/.test(host) || /\/(news|press|press-release)s?\//.test(path)) {
      siteType = 'News / Press';
    } else if (/(forum|community|discuss|board)/.test(host + path)) {
      siteType = 'Forum / Community';
    } else if (/(jobs?|careers?|hiring)/.test(host) || /\/(jobs?|careers?)\//.test(path)) {
      siteType = 'Job Board';
    } else if (/(portfolio|showcase|gallery|inspiration|awards?)/.test(host + path)) {
      siteType = 'Design Showcase';
    } else if (/(directory|listed|listing)/.test(t + ' ' + sn)) {
      siteType = 'Business Directory';
    }
    return { siteName, siteType, domain };
  }

  function normalizeResultUrl(link) {
    try {
      const u = new URL(link);
      u.hash = '';
      const drop = [];
      u.searchParams.forEach((v, k) => { if (/^(utm_|fbclid|gclid|ref$|srsltid)/i.test(k)) drop.push(k); });
      drop.forEach(k => u.searchParams.delete(k));
      let s = u.protocol + '//' + cleanHost(u.hostname) + u.pathname.replace(/\/+$/, '') + (u.search || '');
      return s.toLowerCase();
    } catch (e) {
      return (link || '').toLowerCase();
    }
  }

  function isOwnSite(link, targetRoot) {
    try {
      const host = cleanHost(new URL(link).hostname);
      return host === targetRoot || host.endsWith('.' + targetRoot);
    } catch (e) {
      return false;
    }
  }

  function siteGroup(sites) {
    return '(' + sites.map(s => 'site:' + s).join(' OR ') + ')';
  }

  // Build the list of search queries for a target
  function buildQueries(targetRoot, name, depth) {
    const q = [];
    const n = (name || '').trim();
    const quotedDomain = '"' + targetRoot + '"';
    const quotedName = n ? '"' + n + '"' : quotedDomain;
    const excl = '-site:' + targetRoot;

    const add = (query, page, label) => q.push({ q: query, page: page || 1, label });

    // Quick
    add(`${quotedDomain} ${excl}`, 1, 'Domain mentions');
    if (n) add(`${quotedName} ${excl}`, 1, 'Name mentions');
    add(`${quotedName} ${siteGroup(['clutch.co', 'goodfirms.co', 'designrush.com', 'sortlist.com', 'themanifest.com', 'techbehemoths.com'])}`, 1, 'Agency directories');
    add(`${quotedName} ${siteGroup(['linkedin.com', 'facebook.com', 'instagram.com', 'x.com', 'twitter.com', 'youtube.com'])}`, 1, 'Social profiles');
    add(`${quotedName} ${siteGroup(['behance.net', 'dribbble.com', 'upwork.com', 'fiverr.com', 'trustpilot.com'])}`, 1, 'Portfolio & marketplaces');
    add(`${quotedName} reviews ${excl}`, 1, 'Reviews');

    if (depth === 'standard' || depth === 'deep') {
      add(`${quotedDomain} ${excl}`, 2, 'Domain mentions p2');
      if (n) add(`${quotedName} ${excl}`, 2, 'Name mentions p2');
      add(`${quotedName} ${siteGroup(['crunchbase.com', 'yelp.com', 'bbb.org', 'yellowpages.com', 'g2.com', 'producthunt.com'])}`, 1, 'Business databases');
      add(`${quotedName} ${siteGroup(['medium.com', 'reddit.com', 'quora.com', 'github.com', 'pinterest.com', 'tiktok.com'])}`, 1, 'Community & content');
      add(`${quotedName} ${siteGroup(['agencyspotter.com', 'upcity.com', 'digitalagencynetwork.com', 'topdevelopers.co', 'awwwards.com', 'agencyvista.com'])}`, 1, 'More directories');
      add(`${quotedName} (directory OR listing OR "top agencies" OR "best agencies") ${excl}`, 1, 'Lists & rankings');
    }

    if (depth === 'deep') {
      add(`${quotedDomain} ${excl}`, 3, 'Domain mentions p3');
      add(`${quotedDomain} ${excl}`, 4, 'Domain mentions p4');
      if (n) add(`${quotedName} ${excl}`, 3, 'Name mentions p3');
      if (n) add(`${quotedName} ${excl}`, 4, 'Name mentions p4');
      add(`${quotedName} ${siteGroup(['zoominfo.com', 'rocketreach.co', 'apollo.io', 'owler.com', 'f6s.com', 'wellfound.com'])}`, 1, 'Company databases');
      add(`${quotedName} ${siteGroup(['appfutura.com', 'itfirms.co', 'extract.co', 'expertise.com', 'cssdesignawards.com', 'siteinspire.com'])}`, 1, 'Showcases & directories');
      add(`${quotedName} ${siteGroup(['manta.com', 'hotfrog.com', 'brownbook.net', 'cylex.us.com', 'foursquare.com', 'glassdoor.com'])}`, 1, 'Local directories');
      add(`${quotedName} (interview OR podcast OR featured OR "press release") ${excl}`, 1, 'Press & features');
      add(`${quotedName} ${excl} -site:linkedin.com -site:facebook.com -site:instagram.com -site:x.com`, 1, 'Non-social mentions');
      add(`${quotedName} (portfolio OR "case study" OR showcase) ${excl}`, 1, 'Showcase mentions');
    }
    return q;
  }

  function matchType(item, targetRoot, name) {
    const hay = ((item.title || '') + ' ' + (item.snippet || '') + ' ' + (item.link || '')).toLowerCase();
    const squash = s => s.toLowerCase().replace(/[^a-z0-9]/g, '');
    if (hay.includes(targetRoot.toLowerCase())) return 'Domain mention';
    const n = (name || '').trim();
    if (n && (hay.includes(n.toLowerCase()) || (squash(n).length > 2 && squash(hay).includes(squash(n))))) return 'Name mention';
    return 'Possible match';
  }

  // Sites that need login or block automated page reads; we do not try to fetch these
  const NO_FETCH_HOSTS = [
    'linkedin.com', 'facebook.com', 'instagram.com', 'x.com', 'twitter.com', 'tiktok.com',
    'threads.net', 'google.com', 'pinterest.com', 'quora.com', 'glassdoor.com', 'zoominfo.com'
  ];

  function canFetch(link) {
    try {
      const host = cleanHost(new URL(link).hostname);
      return !NO_FETCH_HOSTS.some(h => host === h || host.endsWith('.' + h));
    } catch (e) {
      return false;
    }
  }

  function hostMatches(host, targetRoot) {
    const h = cleanHost(host);
    return h === targetRoot || h.endsWith('.' + targetRoot);
  }

  function linkKind(relAttr, pageNofollow) {
    const rel = (relAttr || '').toLowerCase();
    if (rel.includes('sponsored')) return 'Sponsored';
    if (rel.includes('ugc')) return 'UGC';
    if (rel.includes('nofollow') || pageNofollow) return 'Nofollow';
    return 'Dofollow';
  }

  // Look inside a page's HTML for links pointing to the target site.
  // Returns { status, linkType, anchor, linksTo, linkCount }
  function analyzeHtml(html, pageUrl, targetRoot) {
    const doc = new DOMParser().parseFromString(html, 'text/html');
    const robots = doc.querySelector('meta[name="robots" i]');
    const pageNofollow = !!(robots && /nofollow/i.test(robots.getAttribute('content') || ''));
    const found = [];
    const anchors = doc.querySelectorAll('a[href], area[href]');
    for (const a of anchors) {
      const raw = a.getAttribute('href') || '';
      let abs;
      try { abs = new URL(raw, pageUrl); } catch (e) { continue; }
      if (!/^https?:$/.test(abs.protocol)) continue;
      let direct = hostMatches(abs.hostname, targetRoot);
      let redirect = false;
      if (!direct) {
        // Redirect / tracking links that carry the target URL in the query string
        let decoded = '';
        try { decoded = decodeURIComponent(abs.search + abs.hash).toLowerCase(); } catch (e) { decoded = (abs.search || '').toLowerCase(); }
        const re = new RegExp('(^|[/.=:@])' + targetRoot.replace(/\./g, '\\.') + '([/?#&"\']|$)');
        if (re.test(decoded)) redirect = true;
      }
      if (!direct && !redirect) continue;
      const anchorText = (a.textContent || a.getAttribute('title') || a.getAttribute('aria-label') ||
        (a.querySelector('img') && (a.querySelector('img').getAttribute('alt') || '[image]')) || '').replace(/\s+/g, ' ').trim();
      let linksTo = abs.href;
      if (redirect) {
        let q = abs.search;
        try { q = decodeURIComponent(abs.search); } catch (e) { /* keep raw */ }
        const m = q.match(/https?:\/\/[^\s&"'<>]+/i);
        linksTo = m ? m[0] : abs.href;
      }
      found.push({ kind: linkKind(a.getAttribute('rel'), pageNofollow), anchor: anchorText, linksTo, redirect });
    }
    if (!found.length) {
      // The page mentions the site but has no clickable link
      return { status: 'Mention only', linkType: '', anchor: '', linksTo: '', linkCount: 0 };
    }
    // Prefer a dofollow direct link as the "main" one to report
    const order = { Dofollow: 0, UGC: 1, Sponsored: 2, Nofollow: 3 };
    found.sort((x, y) => (x.redirect - y.redirect) || (order[x.kind] - order[y.kind]));
    const best = found[0];
    return {
      status: 'Backlink',
      linkType: best.kind + (best.redirect ? ' (redirect)' : ''),
      anchor: best.anchor || '[no text]',
      linksTo: best.linksTo,
      linkCount: found.length
    };
  }

  global.LF = {
    KNOWN_SITES, SITE_TYPES, normalizeInputUrl, rootDomain, cleanHost, guessName,
    classify, normalizeResultUrl, isOwnSite, buildQueries, matchType, canFetch, analyzeHtml
  };
})(typeof window !== 'undefined' ? window : globalThis);
